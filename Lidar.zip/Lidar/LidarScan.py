from rplidar import RPLidar
import pygame
import math


# Spécifiez le port série que vous utilisez pour le LiDAR S1 (par exemple, '/dev/ttyUSB0' sur Linux)
port = 'COM8'  # Changez cela en fonction de votre configuration

# Créez une instance du LiDAR S1
lidar = RPLidar(port)

#Initialisez pygame
pygame.init()

# Créez une fenêtre de 900x600 pixels
lcd = pygame.display.set_mode((900, 600))

# Cachez le curseur de la souris
pygame.mouse.set_visible(False)

# Remplissez l'écran avec du noir
lcd.fill((0, 0, 0))

# Mettez à jour l'écran pour afficher le noir
pygame.display.update()


nb_scan = 0

try:
    # Commencez la collecte de données
    lidar.connect()


    while True:
        for scan in lidar.iter_scans(200000):
            for (_, angle, distance) in scan:
                #Affichez les données du scan sur la fenêtre pygame en utilisant des cercles
                x = 900//2 + int(distance * 299 / 5000 * math.cos(angle * math.pi / 180))
                y = 600//2 + int(distance * 299 / 5000 * math.sin(angle * math.pi / 180))

                #Saturé les valeurs de x et y pour qu'elles restent dans la fenêtre
                if x > 900:
                    x = 899
                if x < 0:
                    x = 1
                if y > 600:
                    y = 599
                if y < 0:
                    y = 1

                pygame.draw.circle(lcd, pygame.Color(0, 255, 0), (x, y), 2)
            #Mettez à jour l'écran pour afficher les cercles toutes les 1 secondes.
            pygame.display.update()
            nb_scan += 1
            #print("Scan terminé : " + str(nb_scan))
            lcd.fill((0, 0, 0))

                

except KeyboardInterrupt:
    pass

finally:
    # Arrêtez la rotation et déconnectez le LiDAR
    lidar.stop_motor()
    lidar.disconnect()
